<?php include "header.php" ?>

<header id="blocked-drain" class="page-header">
  
  <section class="page-header-text">

  	<h1>Blocked Drains</h1>
  	<h4>Adelaide’s best choice for blocked drains services ...</h4>
  	
  </section>

</header><!-- /header -->

<section class="page-content">

	<div class="row">
		<article class="small-12 columns">

		  	<h3>Do you need emergency help from professional plumbers in Adelaide?</h3>
		  	<p>
		  		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		  		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		  		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		  		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		  		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		  		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		  	</p>
		  	
		</article>

	</div>
	
</section>
  

<?php include "footer.php" ?>